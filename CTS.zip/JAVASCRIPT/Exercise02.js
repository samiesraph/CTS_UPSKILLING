const eventName = "Music Festival";
const eventDate = "10-06-2026";
let seats = 50;

console.log(`Event: ${eventName} Date: ${eventDate} Seats: ${seats}`);

seats--;
console.log("Remaining Seats: " + seats);

